import React from 'react';
import { useState } from 'react';

const LayoutHeader = ({ setCurrentPage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md p-4 flex justify-between items-center relative z-10">
      <h1 className="text-2xl font-bold text-gray-800">INSELPRO</h1>
      <nav className="hidden md:flex space-x-6">
        <button onClick={() => setCurrentPage('home')} className="text-gray-600 hover:text-blue-600 transition-colors">Inicio</button>
        <button onClick={() => setCurrentPage('services')} className="text-gray-600 hover:text-blue-600 transition-colors">Servicios</button>
        <button onClick={() => setCurrentPage('about')} className="text-gray-600 hover:text-blue-600 transition-colors">Nosotros</button>
        <button onClick={() => setCurrentPage('contact')} className="text-gray-600 hover:text-blue-600 transition-colors">Contacto</button>
      </nav>
      <div className="md:hidden">
        <button onClick={toggleMenu} className="text-gray-600 focus:outline-none">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
          </svg>
        </button>
      </div>
      {isMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-white shadow-lg md:hidden flex flex-col items-center py-4 space-y-2">
          <button onClick={() => { setCurrentPage('home'); toggleMenu(); }} className="text-gray-600 hover:text-blue-600 transition-colors w-full py-2">Inicio</button>
          <button onClick={() => { setCurrentPage('services'); toggleMenu(); }} className="text-gray-600 hover:text-blue-600 transition-colors w-full py-2">Servicios</button>
          <button onClick={() => { setCurrentPage('about'); toggleMenu(); }} className="text-gray-600 hover:text-blue-600 transition-colors w-full py-2">Nosotros</button>
          <button onClick={() => { setCurrentPage('contact'); toggleMenu(); }} className="text-gray-600 hover:text-blue-600 transition-colors w-full py-2">Contacto</button>
        </div>
      )}
    </header>
  );
};

export default LayoutHeader;