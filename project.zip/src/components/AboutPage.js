import React from 'react';

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8 flex items-center justify-center">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-12 text-center">
        <h2 className="text-5xl font-extrabold text-gray-900 mb-8">Sobre Nosotros</h2>
        <p className="text-lg md:text-xl text-gray-700 mb-6">
          En INSELPRO, contamos con años de experiencia en el sector eléctrico,
          ofreciendo soluciones innovadoras y seguras para clientes residenciales,
          comerciales e industriales. Nuestro equipo de profesionales altamente
          capacitados está comprometido con la excelencia y la satisfacción total
          de cada uno de nuestros clientes.
        </p>
        <p className="text-lg md:text-xl text-gray-700 mb-6">
          Nos enorgullece construir relaciones duraderas basadas en la confianza,
          la transparencia y la calidad de nuestro trabajo. Utilizamos tecnología
          de vanguardia y seguimos los más altos estándares de seguridad para
          garantizar resultados impecables en cada proyecto.
        </p>
        <p className="text-lg md:text-xl text-gray-700">
          Tu seguridad y la eficiencia de tus instalaciones eléctricas son nuestra prioridad.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;