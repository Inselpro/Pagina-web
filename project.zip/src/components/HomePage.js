import React from 'react';

const HomePage = ({ setCurrentPage }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col items-center justify-center text-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 max-w-4xl mx-auto transform transition-all duration-500 hover:scale-105">
        <h2 className="text-4xl md:text-6xl font-extrabold text-gray-900 mb-6 leading-tight">
          Soluciones Eléctricas <span className="text-blue-600">Confiables</span>
        </h2>
        <p className="text-lg md:text-xl text-gray-700 mb-8">
          En INSELPRO, somos tus instaladores eléctricos profesionales de confianza.
          Garantizamos seguridad, eficiencia y calidad en cada proyecto.
        </p>
        <button
          onClick={() => setCurrentPage('services')}
          className="bg-blue-600 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:bg-blue-700 transition-all duration-300 transform hover:-translate-y-1"
        >
          Descubre Nuestros Servicios
        </button>
      </div>
    </div>
  );
};

export default HomePage;