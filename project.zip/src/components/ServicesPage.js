import React from 'react';

const ServicesPage = () => {
  const services = [
    {
      title: "Instalaciones Residenciales",
      description: "Desde nuevas construcciones hasta remodelaciones, aseguramos sistemas eléctricos seguros y eficientes para tu hogar.",
      icon: "🏠"
    },
    {
      title: "Mantenimiento Industrial",
      description: "Servicios de mantenimiento preventivo y correctivo para garantizar la continuidad operativa de tus sistemas industriales.",
      icon: "🏭"
    },
    {
      title: "Sistemas de Iluminación",
      description: "Diseño e instalación de soluciones de iluminación LED, decorativa y funcional para cualquier espacio.",
      icon: "💡"
    },
    {
      title: "Redes de Baja Tensión",
      description: "Instalación y optimización de redes eléctricas de baja tensión para un suministro de energía estable.",
      icon: "⚡"
    },
    {
      title: "Automatización y Control",
      description: "Implementación de sistemas de automatización para mejorar la eficiencia y el control de tus instalaciones.",
      icon: "🤖"
    },
    {
      title: "Certificaciones y Normativas",
      description: "Asesoría y cumplimiento de todas las normativas eléctricas vigentes para la seguridad de tus proyectos.",
      icon: "📜"
    }
  ];

  const WhatsAppIcon = () => (
    <svg viewBox='0 0 24 24' fill='currentColor' className="w-6 h-6 mr-2">
      <path d='M12.04 2.01c-5.47 0-9.91 4.44-9.91 9.91 0 1.75.46 3.42 1.34 4.88L2.01 22l5.18-1.36c1.4.77 2.97 1.21 4.85 1.21 5.47 0 9.91-4.44 9.91-9.91s-4.44-9.91-9.91-9.91zm4.79 13.61c-.19.33-.76.63-1.09.68-.33.05-.76.08-1.14-.13-.38-.21-1.24-.58-1.62-.85-.38-.27-.65-.32-.9-.13-.25.19-.97.85-1.18 1.09-.21.24-.42.27-.79.09-.37-.19-.97-.36-1.84-1.14-.68-.61-1.14-1.36-1.27-1.59-.13-.23-.01-.36.11-.59.11-.23.27-.42.4-.59.13-.16.19-.27.27-.42.08-.16.04-.29-.02-.42-.05-.13-.47-1.14-.65-1.52-.19-.38-.38-.32-.55-.32-.19 0-.42-.02-.65-.02-.23 0-.61.09-.9.42-.29.33-1.1 1.09-1.1 2.66 0 1.57 1.13 3.07 1.29 3.29.16.22 2.2 3.38 5.29 4.63 3.09 1.25 3.72 1.09 4.39.97.67-.12 1.09-.47 1.25-.71.16-.24.33-.47.49-.71.16-.24.16-.42.11-.59-.05-.17-.19-.27-.4-.38z'/>
    </svg>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-extrabold text-center text-gray-900 mb-12">Nuestros Servicios</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg p-6 flex flex-col items-center text-center transform transition-all duration-300 hover:scale-105 hover:shadow-xl border border-gray-100"
            >
              <div className="text-5xl mb-4">{service.icon}</div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <a
                href="https://wa.me/message/UFUTL2QVQ7VSI1"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-green-500 text-white px-6 py-3 rounded-full text-lg font-semibold shadow-md hover:bg-green-600 transition-all duration-300"
              >
                <WhatsAppIcon />
                ¡Contáctanos por WhatsApp!
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;

// DONE