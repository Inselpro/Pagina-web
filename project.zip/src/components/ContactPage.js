import React from 'react';

const ContactPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-8 flex items-center justify-center">
      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-10 text-center">
        <h2 className="text-5xl font-extrabold text-gray-900 mb-8">Contáctanos</h2>
        <p className="text-lg text-gray-700 mb-6">
          ¿Necesitas una cotización o tienes alguna pregunta? ¡Estamos para ayudarte!
          Envíanos un mensaje y nos pondremos en contacto contigo a la brevedad.
        </p>
        <form className="space-y-6">
          <div>
            <input
              type="text"
              placeholder="Tu Nombre"
              className="w-full px-5 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200"
            />
          </div>
          <div>
            <input
              type="email"
              placeholder="Tu Correo Electrónico"
              className="w-full px-5 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200"
            />
          </div>
          <div>
            <textarea
              placeholder="Tu Mensaje"
              rows="5"
              className="w-full px-5 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200 resize-none"
            ></textarea>
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:bg-blue-700 transition-all duration-300 transform hover:-translate-y-1"
          >
            Enviar Mensaje
          </button>
        </form>
        <div className="mt-8 text-gray-700">
          <p className="text-lg">📞 Teléfono: +52 81 2345 6789</p>
          <p className="text-lg">📧 Email: contacto@inselpro.com.mx</p>
          <p className="text-lg">📍 Dirección: Av. Principal #456, Monterrey, N.L.</p>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;

// DONE